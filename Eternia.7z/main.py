from Characters import *
from random import randint
from Attacks import retro_display_text


def choice_classes(name: str):  # choix de la classe du joueur
    def verif_choice_classe_():  # vérifie la validité du choix de la classe du joueur
        choice_classe = input("choisissez votre classe: ")
        if choice_classe.isdigit():
            if int(choice_classe) in range(8):
                return int(choice_classe)
        return verif_choice_classe_()

    retro_display_text(f"\nVeuillez choisir votre classe, {name} :\n")
    retro_display_text("0) Chevalier : (5% force supplémentaire)")
    retro_display_text("1) Sorcier : (esquive la première attaque ennemie)")
    retro_display_text("2) Assassin : (5% de discrétion supplémentaire)")
    retro_display_text("3) Professeur : (5% de précision supplémentaire)")
    retro_display_text("4) Cuisinier : (50 pv supplémentaires)")
    retro_display_text("5) Nécromancien : (5% de vitesse supplémentaire)\n")

    match (verif_choice_classe_()):  # assignation d'une classe à un joueur
        case 0:
            retro_display_text(f"\nnom : {name} | classe sélectionnée : Chevalier\n\n")
            return Knight(name)
        case 1:
            retro_display_text(f"\nnom : {name} | classe sélectionnée : Sorcier\n\n")
            return Wizard(name)
        case 2:
            retro_display_text(f"\nnom : {name} | classe sélectionnée : Assassin\n\n")
            return Assassin(name)
        case 3:
            retro_display_text(f"\nnom : {name} | classe sélectionnée : professeur\n\n")
            return Teacher(name)
        case 4:
            retro_display_text(f"\nnom : {name} | classe sélectionnée : cuisinier\n\n")
            return Chef(name)
        case 5:
            retro_display_text(f"\nnom : {name} | classe sélectionnée : nécromancien\n\n")
            return Necromancer(name)


def main():
    player_1 = choice_classes(str(input("Veuillez rentrer votre nom, joueur 1 : ")))
    player_2 = choice_classes(str(input("Veuillez rentrer votre nom, joueur 2 : ")))
    player_1.enemy = player_2
    player_1.construct_attacks()  # construction des attaques
    player_2.enemy = player_1
    player_2.construct_attacks()
    if randint(1, 10) % 2 == 1:  # choix aléatoire du joueur qui commence
        current_player = player_1
        other_player = player_2
    else:
        current_player = player_2
        other_player = player_1
    winner = None
    print("------------------------------------------------------------------------------------------------------------"
          "------------------")  # affichage du titre
    print("""
 
       / __ )  ____ _  / /_  / /_   / /  ___          / __ \   / __/          / ____/  / /_  ___    _____   ____    (_)  ____ _
      / __  | / __ `/ / __/ / __/  / /  / _ \        / / / /  / /_           / __/    / __/ / _ \  / ___/  / __ \  / /  / __ `/
     / /_/ / / /_/ / / /_  / /_   / /  /  __/       / /_/ /  / __/          / /___   / /_  /  __/ / /     / / / / / /  / /_/ / 
    /_____/  \__,_/  \__/  \__/  /_/   \___/        \____/  /_/            /_____/   \__/  \___/ /_/     /_/ /_/ /_/   \__,_/  


    """)

    while not winner:   # boucle du jeu qui ne s'arrête que s'il y a un gagnant
        winner = current_player.turn()
        current_player, other_player = other_player, current_player

    retro_display_text(f"\n{winner.name} a gagné !")


main()   # lancement du jeu
# pour garder la fenêtre python active en console, sinon elle se ferme
while True:
    print("", end="")
