import time


def retro_display_text(text, delay=0.0125):  # permet d'afficher un texte de façon rétro
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()


class AttackConventional:
    def __init__(self, name: str, description: str, sentence: str, owner, target, value: float,
                 cooldown: int, effects=None):
        """L'attaque porte un nom, une description, une phrase lorsqu'elle va être réalisée,
        un propriétaire, une cible, une valeur, un cooldown et d'éventuels effets additionnels."""
        if effects is None:
            effects = []
        self.name = name
        self.description = description
        self.sentence = sentence
        self.owner = owner
        self.target = target
        self.value = value
        self.cooldown = cooldown
        self.cooldown_step = 0
        self.effects = effects

    def run(self):
        """Déclenchement de l'attaque si elle n'est pas en cours de rechargement"""
        if self.cooldown_step == 0:
            self.launch()
            self.cooldown_step = self.cooldown
        else:
            self.cooldown_error()

    def launch(self):
        print("")
        if not self.target.dodge:  # si l'adversaire ne possède pas d'esquive
            retro_display_text(self.sentence)
            damage = self.value + (10 * (self.owner.strength + self.owner.speed + self.owner.precision)) // (
                        self.target.defence + self.target.discretion)
            self.target.life -= damage  # le joueur adverse subit des dégâts
            self.display_damage(damage)
            self.launch_effects()  # les effets de l'attaque sont lancés
        else:
            self.dodge_trigger()  # le joueur adverse esquive
        print("")

    def cooldown_error(self):  # l'attaque n'a pas fini d'être rechargée
        retro_display_text("Attaque en cours de rechargement, veuillez patienter")
        self.owner.attack()

    def launch_effects(self):  # lancement des effets de l'attaque prenant immédiatement effet s'ils sont sur soi-même
        for effect in self.effects:
            effect.target.liste_effect.append(effect)
            if effect.target == self.owner:
                effect.run()

    def display_damage(self, value):  # affichage des dégâts de l'attaque
        retro_display_text(f"{self.target.name} perd {value} PV")

    def dodge_trigger(self):  # Le joueur adverse esquive
        retro_display_text(f"{self.target.name} esquive l'attaque")
        self.target.dodge = False


class AttackNone(AttackConventional):  # attaque avec des effets, non physique
    def __init__(self, name: str, description: str, sentence: str, owner,
                 cooldown: int, effects=None):
        super().__init__(name, description, sentence, owner, owner, 0, cooldown, effects)
        if effects is None:
            self.effects = []

    def launch(self):
        print("")
        retro_display_text(self.sentence)
        print("")
        self.launch_effects()


class AttackSetDodgeOn(AttackNone):  # attaque qui n'est pas physique et ajoute une esquive en réserve avec d'éventuels
    # effets additionnels

    def dodge_error(self):  # on ne peut stocker plus d'une esquive
        retro_display_text("\nVous avez déjà une esquive en réserve, veuillez choisir une autre attaque\n")
        self.owner.attack()

    def launch(self):
        if self.target.dodge:
            self.dodge_error()
        else:
            print("")
            retro_display_text(self.sentence)
            print("")
            self.target.dodge = True
            self.launch_effects()
