from Effects import *
from Attacks import *


class Player:

    def __init__(self, name):
        """Caractéristiques de base de tous lees personnages qui changent en fonction de la
         classe de départ choisie"""
        self.life = 500
        self.strength = 100
        self.defence = 100
        self.precision = 100
        self.speed = 100
        self.discretion = 100
        self.gold = 0
        self.enemy = None
        self.name = name
        self.dodge = False
        self.liste_effect = []
        self.liste_attack = []

    def shop(self):  # magasin
        def verif_choice_shop_() -> int:  # vérifie que la valeur du choix est valide
            choice_shop = input("choisissez un article: ")
            if choice_shop.isdigit():
                if int(choice_shop) in range(8):
                    return int(choice_shop)
            return verif_choice_shop_()

        print("-----------------------")
        print(" BIENVENUE AU MAGASIN")
        print("-----------------------")
        print("\n(Tous les articles coûtent 100 pièces d'or)\n")
        retro_display_text("0) Potion de Force : +25% (permanent)")
        retro_display_text("1) Potion de Défense : +25% (permanent)")
        retro_display_text("2) Potion de Précision : +25% (permanent)")
        retro_display_text("3) Potion de Discrétion : +25% (permanent)")
        retro_display_text("4) Potion de Vitesse : +25% (permanent)")
        retro_display_text("5) Potion de Vie : + 50PV")
        retro_display_text("6) Faire un don de 50 pièces d'or")
        retro_display_text("7) Annuler")
        match verif_choice_shop_():
            case 0:
                self.strength *= 1.25  # augmentation de la statistique (ici de force)
                retro_display_text(f"\n{self.name} gagne 25 % de force de manière permanente")
                self.gold -= 100  # perte de 100 pièces d'or
            case 1:
                self.defence *= 1.25
                retro_display_text(f"\n{self.name} gagne 25 % de défense de manière permanente")
                self.gold -= 100
            case 2:
                self.precision *= 1.25
                retro_display_text(f"\n{self.name} gagne 25 % de précision de manière permanente")
                self.gold -= 100
            case 3:
                self.discretion *= 1.25
                retro_display_text(f"\n{self.name} gagne 25 % de discrétion de manière permanente")
                self.gold -= 100
            case 4:
                self.speed *= 1.25
                retro_display_text(f"\n{self.name} gagne 25 % de vitesse de manière permanente")
                self.gold -= 100
            case 5:
                self.life += 50
                retro_display_text(f"\n{self.name} gagne 50 PV")
                self.gold -= 100
            case 6:
                self.gold -= 50
            case 7:
                self.choice_action()  # retour au menu d'actions du joueur

    def increase_attack_cooldown(self):  # incrémente le temps de rechargement des attaques
        for attack in self.liste_attack:
            if attack.cooldown_step != 0:
                attack.cooldown_step -= 1

    def attack(self):
        print()
        for index, attack in enumerate(self.liste_attack):  # affichage de toutes les attaques de la classe
            if attack.cooldown_step != 0:
                print(f"{index}) \"{attack.name}\" ({attack.description} ) -> prêt dans {attack.cooldown_step} "
                      f"tour/s")  # affichage du nom de l'attaque, de sa description et de son cooldown (temps de
                # temps de rechargement.
            else:
                print(
                    f"{index}) \"{attack.name}\" ({attack.description} ) -> prêt")
        print("5) annuler")
        choice = self.choice_attack_index()
        if choice == 5:
            self.choice_action()  # retour au menu de choix d'action
        else:
            self.liste_attack[choice].run()
            self.increase_attack_cooldown()  # incrémentation du cooldown de toutes les attaques

    def choice_attack_index(self): # vérification de la validité du choix de l'attaque
        choice_attack = input("\nchoisissez votre attaque: ")
        if choice_attack.isdigit():
            if 0 <= int(choice_attack) <= len(self.liste_attack):
                return int(choice_attack)
        return self.choice_attack_index()

    def choice_action(self):
        print("\n 1) attaquer")
        print(" 2) magasin")
        print(" 3) passer son tour")
        print(" 4) se suicider")
        chosen_action = input("\nvotre choix: ")  # choix du joueur

        match chosen_action:
            case "1":  # le joueur attaque
                self.attack()
                self.gold += 50
            case "2":  # le joueur va au magasin
                if self.gold >= 100:
                    self.shop()
                else:  # le joueur se fait renvoyer du magasin
                    retro_display_text("\nRevenez quand vous aurez au moins 100 pièces d'or")
                return self.choice_action()
            case "3":  # le joueur passe son tour
                retro_display_text("\nVous passez votre tour")
                self.increase_attack_cooldown()
                self.gold += 50
                return None
            case "4":  # le joueur se suicide
                retro_display_text("\nQuelle générosité, offrir la victoire à l'ennemi!")
                return self.enemy
            case _:  # le joueur a rentré n'importe quoi, on lui repropose le choix
                retro_display_text("\nVous semblez indécis")
                return self.choice_action()

    def turn(self):
        if self.life <= 0:
            return self.enemy
        else:
            print(
                "\n------------------------------------------------------------------------------------------------------------"
                "------------------")
            print(f"Tour de {self.name}\n")  # affichage du joueur qui va jouer
            for effect in self.liste_effect:
                effect.run()  # déclenchement de tous les effets actuels du joueur
                if self.life == 0:
                    return self  # on vérifie que le joueur n'est pas mort à cause des effets
            print("\n-> PV du joueur :  ", int(self.life))  # affichage de la vie du joueur
            print(f"-> PV de l'adversaire ({self.enemy.name}): ", int(self.enemy.life))  # affichage de la vie de l'adversaire
            print(f"\nor : {self.gold}\n")  # affichage de l'or du joueur
            if self.liste_effect:  # affichage des effets actuels sur le joueur
                print("Effets actuels sur le joueur :")
                for effect in self.liste_effect:
                    print("-> " + str(effect.name + str(" (" + effect.description + "), ") +
                                      str(effect.duration - effect.state_duration + 1) +
                                      " tour/s restant/s"))
            else:
                print("effets actuels sur le joueur : aucun")
            print("\nEsquive de la prochaine attaque : " + ("oui" if self.dodge else "non"))  # le joueur a-t-il une esquive en réserve ?
            print("\nQue souhaitez vous faire? :")
            # on attend que le joueur appuie sur entrée
            suite = input("<appuyez sur entrée>")  # permet de simuler une étape de scrolling en appuyant sur la touche entrée
            while suite != "":
                suite = input("<appuyez sur entrée>")
            return self.choice_action()


class Knight(Player):

    def __init__(self, name: str):
        super().__init__(name)
        self.strength *= 1.05

    def construct_attacks(self):
        self.liste_attack = [
            AttackConventional("Coup d'épée", "50 dégâts, recharge : 2 tours",
                               str(f"{self.name} se jeta en avant avec une impulsion dévastatrice, brandissant son "
                                   f"épée avec une maîtrise mortelle.\nLe son métallique de l'épée fend l'air avant "
                                   f"de trancher à travers la défense de {self.enemy.name}, pénétrant sa chair avec "
                                   f"une force considérable, \nfaisant jaillir le sang et infligeant des dégâts mortels"
                                   f".\n"), self,
                               self.enemy, 50, 2),
            AttackConventional("Lance de guerre", "70 dégâts, -25% équilibre ennemi (2 tours), recharge : 3 tours",
                               str(f"{self.name} brandit sa lance de guerre avec fureur, abattant l'arme sur "
                                   f"{self.enemy.name} avec une violence brutale.\nLe son métallique de la lance qui "
                                   f"fend l'air est assourdissant, créant une onde de choc qui ébranle même les "
                                   f"murs.\nL'impact projette {self.enemy.name} en arrière, le/la déséquilibrant et "
                                   f"le/la laissant vulnérable.\n"), self, self.enemy,
                               70, 3, [EffectPrecision("déséquilibre", "Précision : -25%", self.enemy, -0.25, 2)]),
            AttackConventional("Frappe de bouclier", "60 dégâts, -30% équilibre ennemi (2 tours), recharge : 3 tours",
                               str(f"{self.name} charge en avant avec son bouclier équipé de pointes et de lames pour "
                                   f"augmenter les dégâts infligés.\nLe son assourdissant du bouclier frappant "
                                   f"{self.enemy.name} résonne dans tout le champ de bataille, \nle/la projettant "
                                   f"en arrière et le/la laissant lutter pour retrouver son équilibre.\n"), self,
                               self.enemy, 60, 3,
                               [EffectPrecision("déséquilibre", "Précision : -25%", self.enemy, -0.25, 2)]),
            AttackNone("Cri de guerre", "+50% force et défense (3 tours), recharge : 4 tours",
                       str(f"{self.name} pousse un rugissement assourdissant qui fait trembler les murs et le sol.\n"
                           f"{self.enemy.name}, terrifié par l'aura de puissance qui l'entoure, \nest pris de panique "
                           f"alors que {self.name} devient plus fort et plus féroce, \nfrappant avec une violence "
                           f"inouïe et résistant à toutes les attaques.\n"), self, 4,
                       [EffectStrength("renforcement", "Force : +50%", self, 0.5, 3),
                        EffectDefence("protection", "Défense : +50%", self, 0.5, 3)]),
            AttackNone("Rage", "+50% force & soin de 35 PV (3 tours), recharge : 5 tours",
                       str(f"{self.name} plonge dans un état de rage qui le remplit d'une énergie brute et "
                           f"destructrice.\nIl/elle inflige des coups dévastateurs, brisant les os et pulvérisant les "
                           f"armures ennemies, \ntout en récupérant de l'énergie vitale en continu, faisant de lui "
                           f"un/e combattant/e redoutable et impitoyable."), self, 5,
                       [EffectStrength("renforcement", "Force : +50%", self, 0.5, 3),
                        EffectLife("soin", "Vie : +35 PV", self, 35, 3)])
        ]


class Wizard(Player):

    def __init__(self, name: str):
        super().__init__(name)
        self.dodge = True

    def construct_attacks(self):
        self.liste_attack = [
            AttackNone("Rune de soin", "soin de 50 PV, recharge : 2 tours",
                       str(f"{self.name} invoque crée une rune lumineuse qui flotte devant lui.\n"
                           f"Ses blessures se dissipent instantanément sous la lueur apaisante, \nson corps se "
                           f"régénérant à vue d'œil dans une explosion de lumière."), self, 2,
                       [EffectLife("soin", "Vie : + 50PV", self, 50, 1)]),
            AttackConventional("Boule de feu", "50 dégâts, +20 dégâts (2 tours), recharge : 3 tours",
                               str(f"Avec un geste rapide, {self.name} canalise son énergie magique pour créer une "
                                   f"boule de feu brûlante dans sa main.\nCette boule de feu dévastatrice "
                                   f"engloutit tout sur son passage, laissant derrière elle des cendres et des cris "
                                   f"de douleur chez {self.enemy.name}.\n"), self,
                               self.enemy, 50, 3, [EffectLife("brûlure", "Vie : -20PV", self.enemy, -20, 2)]),
            AttackNone("Barrière de glace", "-50% vitesse ennemie, +50% défense (2 tours), recharge : 3 tours",
                       str(f"{self.name} invoque une barrière de glace impénétrable qui ralentit et emprisonne "
                           f"{self.enemy.name} dans un mur de glace.\nLa défense de {self.name} augmente, tandis que "
                           f"les cris de douleur de {self.enemy.name} gelé résonnent dans le champ de bataille."),
                       self, 3,
                       [EffectSpeed("ralentissement", "Vitesse : -50%", self.enemy, -0.5, 2),
                        EffectDefence("protection", "Défense : -50%", self, 0.5, 2)]),
            AttackSetDodgeOn("Sort de téléportation", "esquive de la prochaine attaque, recharge : 4 tours",
                             str(f"En un éclair, {self.name} se concentre et disparaît sous les yeux de "
                                 f"{self.enemy.name}, ne laissant derrière lui/elle qu'une traînée de lumière.\n"
                                 f"Réapparaissant dans un endroit sûr, il/elle peut désormais choisir le moment idéal "
                                 f"pour contre-attaquer."), self, 4),
            AttackNone("Invocation de dragon",
                       "invoque un dragon invulnérable (30 dégâts) (3 tours), recharge : 5 tours",
                       str(f"{self.name} lève son sceptre et invoque un dragon majestueux qui atterrit avec fracas "
                           f"sur le champ de bataille, \nprovoquant la terreur de {self.enemy.name}.\nLe dragon déploie"
                           f" sa force incroyable et se déchaîne."), self, 5,
                       [EffectLife("morsure de dragon", "Vie : -30PV", self.enemy, -30, 3)])
        ]


class Assassin(Player):

    def __init__(self, name: str):
        super().__init__(name)
        self.discretion *= 1.05

    def construct_attacks(self):
        self.liste_attack = [
            AttackConventional("Tir rapide", "35 dégâts, recharge : 1 tour",
                               str(f"{self.name} sort son arc en un éclair, tendant la corde à une vitesse "
                                   f"ahurissante.\nSa flèche fend l'air avec une trajectoire impossible à suivre, "
                                   f"atteignant sa cible avec une précision meurtrière.\nLe bruit de la flèche "
                                   f"s'enfonçant dans la chair de {self.enemy.name} est le seul son audible avant "
                                   f"qu'il/elle ne s'effondre.\n"), self,
                               self.enemy, 35, 1),
            AttackConventional("Attaque furtive", "45 dégâts, +25% discrétion (3 tours), recharge : 2 tours",
                               str(f"{self.name} se déplace silencieusement dans l'obscurité, dissimulé par l'ombre.\n"
                                   f"Il/elle apparaît soudainement derrière {self.enemy.name}, lui portant un coup "
                                   f"fatal avant de disparaître à nouveau, \nne laissant derrière lui/elle qu'une "
                                   f"impression de terreur et de confusion dans l'esprit de {self.enemy.name}.\n"),
                               self, self.enemy, 45, 2,
                               [EffectDiscretion("camouflage", "Discrétion : +25%", self, 0.25, 3)]),
            AttackSetDodgeOn("Esquive", "esquive de la prochaine attaque, +25% vitesse (2 tours), recharge : 4 tours",
                             str(f"Avec une agilité presque surnaturelle, \n{self.name} esquive l'attaque de "
                                 f"{self.enemy.name} avec une fluidité déconcertante, \nbondissant de côté avec une "
                                 f"grâce incomparable avant de contre-attaquer avec une violence inouïe.\n"), self, 4,
                             [EffectSpeed("accélération", "Vitesse : +25%", self, 0.25, 2)]),
            AttackNone("Vol", "vol de la moitié de l'or ennemi, recharge : 4 tours",
                       str(f"{self.name} se glisse silencieusement derrière sa cible, \nses doigts agiles se déplaçant "
                           f"avec une précision inouïe pour saisir l'or qu'il convoite.\n{self.enemy.name}, prise au "
                           f"dépourvu, ne peut que regarder impuissant/e sa bourse vidée alors que {self.name} "
                           f"disparaît dans les ombres avec son butin.\n"), self, 4,
                       [EffectGold("vol", "Or : +50% (or ennemi)", self.enemy, self, 0.5)]),
            AttackNone("Assassinat", "+50% discrétion, vitesse et défense (3 tours), recharge : 5 tours",
                       str(f"{self.name} se glisse dans les ombres, \ninvisible aux yeux de {self.enemy.name}, avant de "
                           f"surgir soudainement et porter une attaque rapide et mortelle.\n{self.enemy.name} "
                           f"git au sol dans une marre de sang, dans un état d'incompréhension absolu.\n"), self, 5,
                       [EffectDiscretion("camouflage", "Discrétion : +50%", self, 0.5, 3),
                        EffectSpeed("accélération", "Vitesse : +50%", self, 0.5, 3),
                        EffectDefence("défense", "Défense : +50%", self, 0.5, 3)])
        ]


class Teacher(Player):

    def __init__(self, name: str):
        super().__init__(name)
        self.precision *= 1.05

    def construct_attacks(self):
        self.liste_attack = [
            AttackConventional("Savoir encyclopédique", "40 dégâts, -25% défense ennemie (2 tours), recharge : 2 tours",
                               str(f"{self.name}, empli d'une connaissance encyclopédique, inonde {self.enemy.name} "
                                   f"d'un flot de théories et de faits.\nSon cerveau est assommé par la quantité "
                                   f"d'informations, le/la laissant étourdi et sans défense.\n"),
                               self, self.enemy, 40, 2,
                               [EffectDefence("exposition", "Défense : -25%", self.enemy, -0.25, 2)]),
            AttackNone("Encouragement", "soin de 30 PV, +25% force et défense (3 tours), recharge : 3 tours",
                       str(f"{self.name} se met à hurler des encouragements puissants, augmentant sa force et sa "
                           f"défense tout en soignant ses blessures.\nSes paroles s'élèvent en un crescendo "
                           f"frénétique, \nle stimulant pour qu'il/elle combatte avec une force nouvelle et "
                           f"dévastatrice.\n"), self, 3,
                       [EffectLife("soin", "Vie : +30PV", self, 30, 1),
                        EffectStrength("renforcement", "Force : +25%", self, 0.25, 3),
                        EffectDefence("protection", "Défense : +25%", self, 0.25, 3)]),
            AttackConventional("Conférence ennuyeuse", "30 dégâts, -50% vitesse ennemie (3 tours), recharge : 3 tours",
                               str(f"{self.name} lance une conférence ennuyeuse interminable, assommant "
                                   f"{self.enemy.name} de paroles monotones et affaiblissant sa défense tout en lui "
                                   f"infligeant des dégâts psychologiques et physiques.\n{self.enemy.name} sombre dans"
                                   f" un état d'ennui profond, incapable de réagir alors que le professeur se prépare"
                                   f" à l'anéantir.\n"), self,
                               self.enemy, 30, 3,
                               [EffectSpeed("ralentissement", "Vitesse : -50%", self.enemy, -0.5, 3)]),
            AttackSetDodgeOn("Charge mentale",
                             "+50% precision (2 tours), esquive de la prochaine attaque, recharge : 4 tours",
                             str(f"{self.name} concentre toute sa force psychique dans une attaque mentale fulgurante"
                                 f" qui frappe {self.enemy.name} avec une précision dévastatrice, \nlaissant son esprit"
                                 f" tourmenté et ses sens en état de choc.\n"), self, 4,
                             [EffectPrecision("concentration", "Précision : +50%", self, 0.5, 2)]),
            AttackConventional("Contrôle surprise", "80 dégâts, -50% force ennemie (4 tours), recharge : 5 tours",
                               str(f"{self.name} utilise sa voix douce pour hypnotiser son ennemi, \naffaiblissant sa "
                                   f"force mentale avant de l'attaquer violemment avec un série d'interrogations "
                                   f"surprises.\n{self.enemy.name}, désorienté/e et impuissant/e, est sonné/e "
                                   f"par sa propre ignorance.\n"), self, self.enemy, 80, 5,
                               [EffectStrength("fatigue", "Force : -50%", self.enemy, -0.5, 4)])
        ]


class Chef(Player):

    def __init__(self, name: str):
        super().__init__(name)
        self.life += 50

    def construct_attacks(self):
        self.liste_attack = [
            AttackConventional("Coup de couteau ", "50 dégâts, recharge : 2 tours",
                               str(f"{self.name} se jette sur {self.enemy.name} avec un couteau de cuisine à la main, "
                                   f"visant les parties vitales de son corps avec une précision mortelle.\nSon attaque"
                                   f" rapide et puissante fait pénétrer la lame dans la chair de son adversaire, "
                                   f"causant des blessures profondes et mortelles.\n"), self, self.enemy, 50, 2),
            AttackConventional("Assaisonnement",
                               "20 dégâts + 20 dégâts (2 tours), -25% défense ennemie (2 tours), recharge : 3 tours",
                               str(f"{self.name}, expert/e en épices, \nattrape une poignée de condiments et les "
                                   f"saupoudre avec violence sur {self.enemy.name}.\nSes yeux, sa bouche et ses "
                                   f"narines sont brûlés par les épices, tandis que les condiments pénètrent sa peau, "
                                   f"le/la laissant faible et vulnérable.\n"), self, self.enemy, 20, 3,
                               [EffectLife("irritation", "Vie : -20PV", self.enemy, -20, 2),
                                EffectDefence("exposition", "Défense : -25%", self.enemy, -0.25, 3)]),
            AttackNone("Plat du jour", "soin de 50 PV, +25% force et défense (3 tours), recharge : 3 tours",
                       str(f"{self.name} se concentre pour préparer son plat spécial, et une fois servi, \nil/elle se "
                           f"régale en récupérant rapidement des points de vie tout en gagnant en force et en "
                           f"défense.\n"), self, 3,
                       [EffectLife("soin", "Vie : +50PV", self, 50, 1),
                        EffectStrength("renforcement", "Force : +25%", self, 0.25, 3),
                        EffectDefence("protection", "Défense : +25%", self, 0.25, 3)]),
            AttackSetDodgeOn("Cuisson parfaite",
                             "+50% précision (2 tours), esquive de la prochaine attaque, recharge : 4 tours",
                             str(f"{self.name} se concentre sur la cuisson de son plat tout en se préparant à esquiver"
                                 f" la prochaine attaque de {self.enemy.name}.\nSa grande précision lui permet de "
                                 f"frapper violemment avec son plat parfaitement cuit et d'éviter les attaques "
                                 f"ennemies avec une agilité impressionnante.\n"), self, 4,
                             [EffectPrecision("concentration", "Précision : +50%", self, 0.5, 2)]),
            AttackConventional("Dessert surprise", "80 dégâts, -50% vitesse ennemie (4 tours), recharge : 5 tours",
                               str(f"{self.name}, après avoir préparé un dessert mystérieux avec des ingrédients "
                                   f"rares et une dose de magie, le lance vers {self.enemy.name}.\nCe/tte dernier/ère, \n"
                                   f"attiré par la tentation, est instantanément plongé dans un sommeil profond, \n"
                                   f"affaiblissant sa vitesse de déplacement et le/la rendant vulnérables aux "
                                   f"attaques suivantes de {self.name}.\n"), self, self.enemy, 80, 5,
                               [EffectSpeed("ralentissement", "Vitesse : -50%", self.enemy, -0.5, 4)])
        ]


class Necromancer(Player):

    def __init__(self, name: str):
        super().__init__(name)
        self.speed *= 1.05

    def construct_attacks(self):
        self.liste_attack = [
            AttackConventional("Invocation de zombie", "50 dégâts, recharge : 2 tours",
                               str(f"{self.name} invoque un cadavre putride qui s'élève du sol et se dirige lentement"
                                   f" vers {self.enemy.name}.\nLorsque le zombie explose, la chair et le sang volent"
                                   f" dans toutes les directions, \ninfligeant des dégâts importants et laissant"
                                   f" {self.enemy.name} dans un état de choc horrifiant.\n"),
                               self, self.enemy, 50, 2),
            AttackNone("Marche des morts", "-30% vitesse ennemie (4 tours), recharge : 3 tours",
                       str(f"{self.name} invoque une horde de squelettes qui émerge des profondeurs de l'enfer, "
                           f"enveloppant {self.enemy.name} dans un nuage de désolation et de désespoir.\n"
                           f"{self.enemy.name} est ralenti et son moral est sapé, \nle/la plongeant dans un état de "
                           f"désespoir tandis que les ossements grinçants des squelettes résonnent sinistrement dans "
                           f"ses oreilles.\n"),
                       self, 3,
                       [EffectSpeed("ralentissement", "Vitesse : - 30%", self.enemy, -0.3, 4)]),
            AttackNone("Malédiction", "25 dégâts (3 tours), recharge : 3 tours",
                       str(f"Des serpents de fumée noire surgissent du néant et s'enroulent autour de "
                           f"{self.enemy.name}, \nmordant sa chair et injectant un venin mortel qui le/la fait hurler de "
                           f"douleur et le/la laissant agoniser au sol, victime de l'atroce malédiction infligée "
                           f"par le {self.name}.\n"),
                       self, 3,
                       [EffectLife("malédiction", "Vie : - 25PV", self.enemy, -25, 3)]),
            AttackNone("Sacrifice", "soigne 30 PV, +20 pv (2 tours), recharge : 4 tours",
                       str(f"{self.name}, entouré/e d'une aura sombre, commence à absorber l'énergie vitale de ses "
                           f"morts-vivants, \nles faisant hurler de douleur alors que leur force vitale est aspirée "
                           f"pour recharger la santé de leur maître.\nLes cadavres sont soumis à sa volonté, "
                           f"sacrifiés pour renforcer sa magie et sa santé.\n"), self, 4,
                       [EffectLife("soin", "Vie : + 30PV", self, 30, 1),
                        EffectLife("soin", "Vie : + 20PV", self, 20, 2, 1)]),
            AttackNone("Drain de vie", "vole de 60 PV à l'ennemi, recharge : 5 tours",
                       str(f"{self.name} étend sa main vers {self.enemy.name}, libérant une énergie sombre qui "
                           f"envahit son corps, aspirant immédiatement sa vitalité, \nsa santé, sa force, et tout "
                           f"ce qui le maintient en vie.\n{self.enemy.name} est laissé/e affaibli/e et vulnérable "
                           f"alors que {self.name} se régénère, récupérant une partie de la santé qu'il a volée, \n"
                           f"le/la rendant plus fort que jamais.\n"), self, 5,
                       [EffectLife("soin", "Vie : + 60PV", self, 60, 1),
                        EffectLife("aspiration de vie", "Vie : - 60PV", self.enemy, -60, 0)])
        ]
