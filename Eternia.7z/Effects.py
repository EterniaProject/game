from Attacks import retro_display_text


class Effect:
    def __init__(self, name: str, description: str, target, value: float, duration: int):
        """Initialisation de la classe effet possédant le nom de l'effet "name", sa description,
        la cible de l'effet "target", la valeur de la donnée changée et la durée de l'effet"""
        self.name = name
        self.description = description
        self.target = target
        self.value = value
        self.duration = duration
        self.state_duration = 0

    def drop(self):
        """Permet de supprimer définitivement un effet"""
        self.state_duration = 0
        self.target.liste_effect.remove(self)

    def verify_drop(self):
        """Vérifie si l'effet doit être supprimé"""
        if self.state_duration > self.duration:
            self.drop()

    def display_percent(self, setting: str):
        """Affichage du résultat de l'effet touchant des données en pourcentage"""
        if self.value > 0:
            retro_display_text(f"{self.target.name} gagne {self.value * 100}% de {setting}")
        else:
            retro_display_text(f"{self.target.name} perd {-self.value * 100}% de {setting}")


class EffectLife(Effect):

    def __init__(self, name: str, description: str, target, value: float, duration: int, delay=0):
        """L'effet de vie reprend tous les attributs de la classe effet, mais rajoute la notion de délai
        qui permet de différencier les potions des dégâts de malédiction par exemple. Une potion à un effet
        instantané, tandis que la malédiction se déclenche au tour suivant, celui de l'ennemi."""
        super().__init__(name, description, target, value, duration - 1)
        self.delay = delay

    def display(self):
        """Affichage spécifique des conséquences de l'effet de vie"""
        if self.value > 0:
            retro_display_text(f"{self.target.name} gagne {self.value} PV")
        else:
            retro_display_text(f"{self.target.name} perd {-self.value} PV")

    def run(self):
        """Déclenchement de l'effet"""
        if self.delay == 0:
            if (self.state_duration <= self.duration) or self.state_duration == 0:
                self.display()
                self.target.life += self.value
            self.state_duration += 1
            self.verify_drop()  # on vérifie si l'effet est arrivé à la fin de sa durée
        else:
            self.delay -= 1


class EffectStrength(Effect):

    def drop(self):
        while self.state_duration != 0:
            self.target.strength /= (1 + self.value)
            self.state_duration -= 1
        self.target.liste_effect.remove(self)

    def run(self):
        if self.state_duration == 0:
            self.display_percent("force")
            self.target.strength *= (1 + self.value)
        self.state_duration += 1
        self.verify_drop()


class EffectDefence(Effect):

    def drop(self):
        while self.state_duration != 0:
            self.target.defence /= (1 + self.value)
            self.state_duration -= 1
        self.target.liste_effect.remove(self)

    def run(self):
        if self.state_duration == 0:
            self.display_percent("défense")
            self.target.defence *= (1 + self.value)
        self.state_duration += 1
        self.verify_drop()


class EffectPrecision(Effect):

    def drop(self):
        while self.state_duration != 0:
            self.target.precision /= (1 + self.value)
            self.state_duration -= 1
        self.target.liste_effect.remove(self)

    def run(self):
        if self.state_duration == 0:
            self.display_percent("précision")
            self.target.precision *= (1 + self.value)
        self.state_duration += 1
        self.verify_drop()


class EffectSpeed(Effect):

    def drop(self):
        while self.state_duration != 0:
            self.target.speed /= (1 + self.value)
            self.state_duration -= 1
        self.target.liste_effect.remove(self)

    def run(self):
        if self.state_duration == 0:
            self.display_percent("vitesse")
            self.target.speed *= (1 + self.value)
        self.state_duration += 1
        self.verify_drop()


class EffectDiscretion(Effect):

    def drop(self):
        while self.state_duration != 0:
            self.target.discretion /= (1 + self.value)
            self.state_duration -= 1
        self.target.liste_effect.remove(self)

    def run(self):

        if self.state_duration == 0:
            self.display_percent("discrétion")
            self.target.discretion *= (1 + self.value)
        self.state_duration += 1
        self.verify_drop()


class EffectGold(Effect):
    def __init__(self, name: str, description: str, owner_gold, target_gold, value: float):
        """Ici, l'attribut owner sert à savoir qui va se faire voler. Target est le joueur qui vole."""
        super().__init__(name, description, target_gold, value, 0)
        self.owner = owner_gold

    def display(self, money):
        """Affichage des conséquences du vol pour les 2 joueurs"""
        retro_display_text(f"{self.target.name} gagne {money} pièces d'or")
        retro_display_text(f"{self.owner.name} perd {money} pièces d'or")

    def run(self):
        if self.state_duration == 0:
            money_account = self.owner.gold * self.value
            self.display(money_account)
            self.target.gold += money_account
            self.owner.gold -= money_account
        self.state_duration += 1
        self.verify_drop()
